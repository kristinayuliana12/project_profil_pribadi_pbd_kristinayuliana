<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Profil Kristina Yuliana</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  </head>
  <body>
    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
        <ul class="nav navbar-nav">

		}
	</style>

</html>
          
          <img src="img/icon.png" width="50" height="50" style="border-radius: 10%;"/>
        </div>
        <a class="navbar-brand" href="contact">CONTACT ME</a>
        
    </nav>
    <body>
 <p align="center"><font face="Courier New" color="black" size="5">WELCOME TO MY PROFILE</font></p>
 </body>
</html>

    <header style="text-align: center;">
        <img src="img/kris.jpeg" width="230" height="200" style="border-radius: 50%;"/>

        <h1>Kristina Yuliana</h1>
        <head>
  <title>Penggunaan Elemen Font</title>
 </head>
 <body>
 <p align="center"><font face="Andale Mono" color="black" size="5">Assalamualaikum Selamat atang di Website Pribadi Saya</font></p>
 <p align="center"><font face="Andale Mono" color="black" size="5">Website Ini Dibuat Untuk Memenuhi Tugas UTS Pemrograman Basis Data</font></p>

    </header>
    </html><!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
    <style>
      
      body {
        background-color: #808080;
      }
      
      .kartu {
        width: 800px;
        margin: 0 auto;
        margin-top: 70px;
            box-shadow: 0 0.25rem 0.75rem rgba(0,0,0,.03);
    transition: all .3s;
           background-color: #cf88bb;;
    border: solid 8px #ea92ff;
    border-top-right-radius: 100px;
    border-bottom-left-radius: 80px;
      } 
      .kartu:hover {
        background-color: #1f8a45;
        border: solid 8px #4fd47e;
        border-top-left-radius: 80px;
    border-bottom-right-radius: 80px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
      }
      .foto {
            padding: 90px;
    margin-left: 30px;
    margin-top: 50px;
      }
      tbody {
    font-size: 18px;
    font-weight: 300;
    color:white;
}
.biodata {
    margin-top: 0px;
}
    </style>
<div class="container">
  <div class="card kartu">
    <div class="row">
      <div class="col-md-7">
       <div class="col-md-10 kertas-biodata">
        <div class="biodata">
        <table width="200%" border="0">
    <tbody><tr>
        <td valign="top">
        <table border="0" width="100%" style="padding-left: 2px; padding-right: 13px;">
          <tbody>
            <tr>
              <td width="50%" valign="top" class="textt">Nama</td>
                <td width="2%">:</td>
                <td style="color: #F8F8FF; font-weight:bold">Kristina Yuliana</td>
          <tr>
              <td class="textt">Jenis Kelamin</td>
                <td>:</td>
                <td>Perempuan</td>
            </tr>
          <tr>
              <td class="textt">NIM</td>
                <td>:</td>
                <td>19050974054</td>
            
            </tr>
          <tr>
              <td class="textt">Fakultas</td>
                <td>:</td>
                <td>Teknik</td>
            </tr>
          <tr>
              <td valign="top" class="textt">Prodi</td>
                <td valign="top">:</td>
                <td>S1 Pendidikan Teknologi Informasi</td>
           <tr>
              <td valign="top" class="textt">Asal Kampus</td>
                <td valign="top">:</td>
                <td>Universitas Negeri Surabaya</td>
            </tr>
            


  <?php /**PATH C:\xampp\htdocs\projekuts\resources\views/aboutme.blade.php ENDPATH**/ ?>